from pathlib import Path

PYTHON_MODULE_ROOT_PATH = Path(__file__).parent.parent.resolve()