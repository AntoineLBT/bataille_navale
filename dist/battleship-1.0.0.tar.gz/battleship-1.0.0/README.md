# bataille_navale
 Implémentation d'une bataille navale avec placement aléatoire des navires.
